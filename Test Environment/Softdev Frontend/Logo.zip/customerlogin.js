const container = document.querySelector(".container"),
passFields = document.querySelectorAll("password");
